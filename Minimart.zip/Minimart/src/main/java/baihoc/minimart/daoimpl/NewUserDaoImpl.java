/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baihoc.minimart.daoimpl;

import baihoc.minimart.dao.NewUserDao;
import baihoc.minimart.entity.User;
import baihoc.minimart.until.XJdbc;
import baihoc.minimart.until.XQuery;
import java.util.List;

/**
 *
 * @author NGUYEN HUU
 */
public class NewUserDaoImpl implements NewUserDao{

    @Override
   public User login(String username, String password) {
        String sql = "SELECT * FROM Users WHERE Username = ? AND Password = ? AND Enabled = 1";
        return XQuery.getSingleBean(User.class, sql, username, password);
    }


    @Override
    public boolean register(User user) {
        String sql = "INSERT INTO Users (Username, Password, Enabled, Fullname, Photo, Manager) VALUES (?, ?, ?, ?, ?, ?)";
        int rows = XJdbc.executeUpdate(sql,
                user.getUsername(),
                user.getPassword(),
                user.isEnabled(),
                user.getFullname(),
                user.getPhoto(),
                user.isManager()
        );
        return rows > 0;
    }

    @Override
    public boolean isUser(String username, String fullname) {
        String sql = "SELECT * FROM Users WHERE Username = ? OR Fullname = ?";
        List<User> list = XQuery.getBeanList(User.class, sql, username, fullname);
        return !list.isEmpty();
    }

    @Override
    public User findByUsername(String username) {
        String sql = "SELECT * FROM Users WHERE Username = ?";
        return XQuery.getSingleBean(User.class, sql, username);
    }
    
}
