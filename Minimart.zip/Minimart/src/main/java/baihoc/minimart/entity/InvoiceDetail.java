/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baihoc.minimart.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author NGUYEN HUU
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class InvoiceDetail {
    private int detailID;
    private int invoiceID;
    private int productID;
    private int quantity;
    private double unitPrice;
}
