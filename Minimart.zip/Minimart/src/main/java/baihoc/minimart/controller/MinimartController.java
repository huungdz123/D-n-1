/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package baihoc.minimart.controller;

import baihoc.minimart.UImanager.BillManagerJDialog;
import baihoc.minimart.UImanager.CategoryManagerJDialog;
import baihoc.minimart.UImanager.EnterProductManagerJDialog;
import baihoc.minimart.UImanager.ProductManagerJDialog;
import baihoc.minimart.UImanager.RevenueManagerJDialog;
import baihoc.minimart.UImanager.UserManagerJDialog;
import baihoc.minimart.UImanager.WarehouseManagerJDialog;
import baihoc.minimart.ui.HistoryJDialog;
import baihoc.minimart.ui.LoginJDialog;
import baihoc.minimart.ui.SalesJDialog;
import baihoc.minimart.ui.WelcomeJDialog;
import baihoc.minimart.until.XDialog;
import javax.swing.JDialog;
import javax.swing.JFrame;

/**
 *
 * @author ADMIN
 */
public interface MinimartController {
    void init();
    default void exit(){
        if(XDialog.confirm("Bạn muốn kết thúc?")){
        System.exit(0);
        }
    }
    default void showJDialog(JDialog dialog){
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
       
    }
    
    default void showWelcomeJDialog(JFrame frame){
        this.showJDialog(new WelcomeJDialog(frame,true));
    }
    
    default void showLoginJDialog(JFrame frame){
        this.showJDialog(new LoginJDialog(frame,true));
    }
    
    default void showHistoryJDialog(JFrame frame){ 
        this.showJDialog(new HistoryJDialog(frame, true)); 
    } 
    
    default void showCategoryManagerJDialog(JFrame frame){ 
        this.showJDialog(new CategoryManagerJDialog(frame, true)); 
    } 
   
    default void showBillManagerJDialog(JFrame frame){ 
        this.showJDialog(new BillManagerJDialog(frame, true)); 
    } 
    default void showUserManagerJDialog(JFrame frame){ 
        this.showJDialog(new UserManagerJDialog(frame, true)); 
    } 
    default void showRevenueManagerJDialog(JFrame frame){ 
        this.showJDialog(new RevenueManagerJDialog(frame, true)); 
    }
    
    default void showProductManagerJDialog(JFrame frame){ 
        this.showJDialog(new ProductManagerJDialog(frame, true)); 
    }
    
    default void showWarehouseManagerJDialog(JFrame frame){ 
        this.showJDialog(new WarehouseManagerJDialog(frame, true)); 
    }
    
    default void showEnterProductManagerJDialog(JFrame frame){ 
        this.showJDialog(new EnterProductManagerJDialog(frame, true)); 
    }
    default void showSalesJDialog(JFrame frame){ 
        this.showJDialog(new SalesJDialog(frame, true)); 
    }
    
}
