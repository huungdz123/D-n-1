/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package baihoc.minimart.controller;

/**
 *
 * @author NGUYEN HUU
 * @param <Entity>
 */
public interface CrudController<Entity> {
    void open();
    void setForm(Entity entity); 
    Entity getForm(); 
     
    void fillToTable(); 
    void edit(); 
     
    void create(); 
    void update();  
    void delete(); 
    void clear();  
    void setEditable(boolean editable); 
     
    void checkAll();  
    void uncheckAll(); 
    void deleteCheckedItems();   
 
    void moveFirst(); 
    void movePrevious(); 
    void moveNext(); 
      void moveLast(); 
    void moveTo(int rowIndex);
}
