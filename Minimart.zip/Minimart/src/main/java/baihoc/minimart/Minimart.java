/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package baihoc.minimart;

/**
 *
 * @author NGUYEN HUU
 */
public class Minimart {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
