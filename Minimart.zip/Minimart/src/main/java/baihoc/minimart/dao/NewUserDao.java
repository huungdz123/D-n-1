/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package baihoc.minimart.dao;

import baihoc.minimart.entity.User;

/**
 *
 * @author NGUYEN HUU
 */
public interface NewUserDao {
        boolean isUser(String username, String fullname); // ✔ khớp với implements
    User login(String username, String password);
    boolean register(User user);
    User findByUsername(String username);
}
