/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package baihoc.minimart.dao;

import baihoc.minimart.entity.User;

/**
 *
 * @author NGUYEN HUU
 */
public interface UserDao extends CrudDao<User, String>{
    
}
