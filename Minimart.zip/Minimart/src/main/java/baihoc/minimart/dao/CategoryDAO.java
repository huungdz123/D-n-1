/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package baihoc.minimart.dao;

import baihoc.minimart.entity.Category;

/**
 *
 * @author ADMIN
 */
public interface CategoryDAO extends CrudDao<Category, Integer>{
    
}
