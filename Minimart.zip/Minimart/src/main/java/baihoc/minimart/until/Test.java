/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package baihoc.minimart.until;


import baihoc.minimart.entity.Category;
import java.sql.ResultSet;
import java.util.List;
import java.sql.SQLException;

/**
 *
 * @author NGUYEN HUU
 */
public class Test {

    public static void main(String[] args) throws SQLException {
        // 1. Thêm dữ liệu
        String sqlInsert = "INSERT INTO Categories (Id, Name) VALUES(?, ?)";
        XJdbc.executeUpdate(sqlInsert, "C01", "Loai 1");
        XJdbc.executeUpdate(sqlInsert, "C02", "Loai 2");

// 2. Truy vấn nhiều bản ghi (ResultSet thủ công)
        String sqlQuery1 = "SELECT * FROM Categories WHERE Name LIKE ?";
        ResultSet rs = XJdbc.executeQuery(sqlQuery1, "%Loai%");
        while (rs.next()) {
            String id = rs.getString("Id");
            String name = rs.getString("Name");
            System.out.println("ID: " + id + ", Name: " + name);
        }

// 3. Truy xuất nhiều bản ghi và chuyển đổi sang List<Categories>
        String sqlQuery2 = "SELECT * FROM Categories WHERE Name LIKE ?";
        List<Category> list = XQuery.getBeanList(Category.class, sqlQuery2, "%Loai%");
        for (Category cat : list) {
            System.out.println(cat);
        }

// 4. Truy xuất một bản ghi
        String sqlQuery3 = "SELECT * FROM Categories WHERE Id = ?";
        Category category = XQuery.getSingleBean(Category.class, sqlQuery3, "C02");
        System.out.println(category);

// 5. Truy vấn 1 giá trị đơn
        String sqlQuery4 = "SELECT MAX(Id) FROM Categories WHERE Name LIKE ?";
        String maxId = XJdbc.getValue(sqlQuery4, "%Loai%").toString();
        System.out.println("max(Id) = " + maxId);

    }
}
